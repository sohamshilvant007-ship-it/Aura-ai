# Aura AI — Backend + Frontend Setup

## Ye kaise kaam karta hai (simple flow)

```
User bolta/type karta hai
        ↓
  FRONTEND (index.html) — jo user ko dikhta hai
        ↓  (message bhejta hai)
  BACKEND (server.js) — chhipi hui API key ke saath
        ↓  (Gemini AI ko call karta hai)
     Gemini AI
        ↓  (jawab wapas)
  BACKEND
        ↓
  FRONTEND
        ↓
  User ko jawab dikhta hai
```

Backend zaroori hai agar aap chahte ho ki **jo bhi aapki website use kare, unhe apni API key na deni pade** — key sirf server pe (aapke paas) rahegi.

## Step 1 — Backend deploy karo (free)

Ye Node.js server hai. Free hosting ke liye **Render.com** sabse aasan hai:

1. `backend` folder ko GitHub pe ek naye repo mein upload karo (⚠️ `.env` file upload mat karna — wo `.gitignore` mein already excluded hai)
2. [render.com](https://render.com) pe account banao, "New Web Service" banao, apna GitHub repo connect karo
3. Build command: `npm install`
4. Start command: `npm start`
5. Environment Variables mein add karo: `GEMINI_API_KEY` = aapki asli Gemini key
6. Deploy dabao — kuch minute mein ek URL milega, jaise: `https://aura-backend-xyz.onrender.com`

## Step 2 — Frontend ko backend se jodo

1. `index.html` file ko Chrome mein kholo
2. **⚙️ Settings** button dabao
3. "Option A — Apna Backend" mein apna URL paste karo (jo Render se mila)
4. Save karo

Bas! Ab jo bhi is `index.html` (ya isse bani website) ko use karega, unke messages aapke backend se hoke jaayenge — unhe kabhi apni key nahi deni padegi.

## Step 3 — Website banane ke liye

`index.html` ko **Netlify** ya **GitHub Pages** pe upload karo (dono free hain) — turant ek live link mil jayega jo kisi ko bhi bhej sakte ho.

## Local pe test karna ho (deploy se pehle)

```
cd backend
npm install
cp .env.example .env
# .env file kholo aur GEMINI_API_KEY daalo
npm start
```

Fir Settings mein backend URL daalo: `http://localhost:3000`

## Zaroori baatein

- `.env` file (jisme aapki asli key hai) **kabhi kisi ko mat bhejo, kabhi GitHub pe mat daalo**
- Agar Option A (backend) set hai, to woh use hoga. Agar nahi hai, to Option B (personal key) ya phir 🧠 offline AI ya Wikipedia fallback use hoga
- Free hosting (Render free tier) thoda slow start hota hai agar der tak use na ho — pehla reply thoda time le sakta hai
